
import memorizeResult from '../supports/memorize-result';
import tabsequenceSortsAreaAtImagePosition from '../supports/tabsequence-area-at-img-position';

export default memorizeResult(function() {
  return {
    tabsequenceSortsAreaAtImagePosition: tabsequenceSortsAreaAtImagePosition(),
  };
});
