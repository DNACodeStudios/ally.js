
// exporting modules to be included the UMD bundle

import disabled from './disabled';
export default {
  disabled,
};
