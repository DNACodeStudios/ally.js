
// exporting modules to be included the UMD bundle

import interactionType from './interaction-type';
export default {
  interactionType,
};
