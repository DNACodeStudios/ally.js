
// this file is overwritten by `npm run build:pre`
const version = '1.1.0-beta.2';
export default version;
