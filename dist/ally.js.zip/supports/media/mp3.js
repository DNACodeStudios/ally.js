
//export default 'data:audio/mp3;base64,audio-focus-test';
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _gif = require('./gif');

var _gif2 = _interopRequireDefault(_gif);

exports['default'] = _gif2['default'];
module.exports = exports['default'];
//# sourceMappingURL=mp3.js.map