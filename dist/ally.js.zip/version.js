
// this file is overwritten by `npm run build:pre`
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});
var version = '1.1.0-beta.2';
exports['default'] = version;
module.exports = exports['default'];
//# sourceMappingURL=version.js.map