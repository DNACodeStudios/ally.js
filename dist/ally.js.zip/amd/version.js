define(['exports', 'module'], function (exports, module) {
  // this file is overwritten by `npm run build:pre`
  'use strict';

  var version = '1.1.0-beta.2';
  module.exports = version;
});
//# sourceMappingURL=version.js.map