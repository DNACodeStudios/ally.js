define(['exports', 'module', './disabled'], function (exports, module, _disabled) {
  // exporting modules to be included the UMD bundle

  'use strict';

  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

  var _disabled2 = _interopRequireDefault(_disabled);

  module.exports = {
    disabled: _disabled2['default']
  };
});
//# sourceMappingURL=_element.js.map