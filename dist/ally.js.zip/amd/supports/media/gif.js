define(['exports', 'module'], function (exports, module) {
  'use strict';

  module.exports = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
});
//# sourceMappingURL=gif.js.map