define(['exports', 'module', './gif'], function (exports, module, _gif) {
  //export default 'data:audio/mp3;base64,audio-focus-test';
  'use strict';

  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

  var _gif2 = _interopRequireDefault(_gif);

  module.exports = _gif2['default'];
});
//# sourceMappingURL=mp3.js.map