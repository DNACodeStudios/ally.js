define(['exports', 'module'], function (exports, module) {
  'use strict';

  module.exports = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ';
});
//# sourceMappingURL=gif.invalid.js.map